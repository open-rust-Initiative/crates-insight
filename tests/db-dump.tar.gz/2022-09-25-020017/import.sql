BEGIN;
    \cd :scriptdir
COMMIT;